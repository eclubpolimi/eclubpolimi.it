import {
  require_react_dom
} from "./chunk-AUFLGUIX.js";
import "./chunk-PSQR3SVX.js";
import "./chunk-5WRI5ZAA.js";
export default require_react_dom();
